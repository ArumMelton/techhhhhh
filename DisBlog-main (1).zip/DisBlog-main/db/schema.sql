DROP DATABASE IF EXISTS  developing_tech_db;

CREATE DATABASE  developing_tech_db;